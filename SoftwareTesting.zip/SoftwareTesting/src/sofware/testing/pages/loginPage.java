package sofware.testing.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class loginPage {
	
	private static WebElement element = null;

	// click Percentage calculator
	public static void click_submit_button(WebDriver driver) 
	{
		driver.findElement(By.id("btnLogin")).click();
//		element = driver.findElement(By.id("btnLogin"));
//		return element;
	}

//	// Input 1 in textbox
//	public static WebElement txt_num_1(WebDriver driver) {
//		element = driver.findElement(By.id("cpar1"));
//		return element;
//	}
//
//	// Input 2 in textbox
//
//	public static WebElement txt_num_2(WebDriver driver) {
//		element = driver.findElement(By.id("cpar2"));
//		return element;
//	}
//
//	// click calculate button
//	public static WebElement btn_calc(WebDriver driver) {
//		element = driver.findElement(By.xpath(".//*[@id='content']/table[1]/tbody/tr[2]/td/input[2]"));
//		return element;
//
//	}
//
//	// Calculated result
//	public static WebElement calc_result(WebDriver driver) {
//		element = driver.findElement(By.xpath(".//*[@id='content']/p[2]/font/b"));
//		return element;
//	}
//	
//	public static WebElement calc_diff_txt1(WebDriver driver)
//	{
//		element = driver.findElement(By.xpath(".//*[@id='content']/table[5]/tbody/tr[1]/td[2]/input"));
//		return element;
//		
//	}
//	
//	public static WebElement calc_diff_txt2(WebDriver driver)
//	{
//		element = driver.findElement(By.xpath(".//*[@id='content']/table[5]/tbody/tr[2]/td[2]/input"));
//		return element;
//	}
//	
//	public static WebElement calc_diff_btn_click(WebDriver driver)
//	{
//		element = driver.findElement(By.xpath(".//*[@id='content']/table[5]/tbody/tr[3]/td/input[2]"));
//		return element;
//	}

}
