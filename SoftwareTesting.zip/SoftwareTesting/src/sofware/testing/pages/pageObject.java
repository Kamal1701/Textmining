package sofware.testing.pages;

public class pageObject {
	
	public void callprint() {
		System.out.println("page object class");
	}

}
