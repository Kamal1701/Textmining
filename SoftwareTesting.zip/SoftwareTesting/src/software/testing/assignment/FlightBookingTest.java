package software.testing.assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
//import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FlightBookingTest {

	public String baseUrl = "http://newtours.demoaut.com";
	public String driverPath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
	public WebDriver driver;
	//loginPage ln;

	@BeforeTest
	public void invokeBrowser() {
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to(baseUrl);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Test(priority=1)
	public void click_submit() throws Exception {
		Thread.sleep(2000);
		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userName")).sendKeys("admin");
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("mercury");
		CaptureScrShot.takeSnapShot(driver, "FlightBookingLoginPage.png");
		driver.findElement(By.name("login")).click();
		String ExpectedTitle = "Find a Flight: Mercury Tours:";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, ExpectedTitle);
	}

	@Test(priority=2)
	public void click_continue_button() throws Exception {
		
		driver.findElement(By.xpath("//input[@name='tripType' and @value='oneway']")).click();
		driver.findElement(By.xpath("//input[@name='findFlights']")).click();
		CaptureScrShot.takeSnapShot(driver, "FindFlight.png");
		//Assert.assertEquals(actualTitle, ExpectedTitle);
	}
	
	@Test(priority=3)
	public void select_flights() throws Exception {
		
		driver.findElement(By.xpath("//form[@name='results']/table/tbody/tr[5]/td/input[@name='outFlight']")).click();
		driver.findElement(By.xpath("//form[@name='results']/table[2]/tbody/tr[5]/td/input[@name='inFlight']")).click();
		CaptureScrShot.takeSnapShot(driver, "SelectFlight.png");
		driver.findElement(By.xpath("//input[@name='reserveFlights']")).click();
		//Assert.assertEquals(actualTitle, ExpectedTitle);
	}
	
	@Test(priority=4)
	public void book_the_flights() throws Exception {
		
		driver.findElement(By.xpath("//input[@name='passFirst0']")).sendKeys("Vasugi");
		driver.findElement(By.xpath("//input[@name='passLast0']")).sendKeys("Narashiman");
		driver.findElement(By.xpath("//input[@name='creditnumber']")).sendKeys("0000111100001111");
		Select expMon = new Select(driver.findElement(By.name("cc_exp_dt_mn")));
		expMon.selectByVisibleText("01");
		expMon.selectByIndex(1);
		Select expYr = new Select(driver.findElement(By.name("cc_exp_dt_yr")));
		expYr.selectByVisibleText("2000");
		expYr.selectByIndex(1);
		CaptureScrShot.takeSnapShot(driver, "SelectFlight.png");
		driver.findElement(By.xpath("//input[@name='buyFlights']")).click();
		//Assert.assertEquals(actualTitle, ExpectedTitle);
	}
	
	@Test(priority=5)
	public void flight_confirmation() throws Exception {
		
		driver.findElement(By.xpath("//table/tbody/tr/td/b/font/font/b/font[1][contains(text(),'Flight')]")).getText();
		CaptureScrShot.takeSnapShot(driver, "FlightConfirmation.png");
		
		//Assert.assertEquals(actualTitle, ExpectedTitle);
	}
	
	
	@Test(priority=6)
	public void validate_logout() throws Exception {
		driver.findElement(By.xpath("//table/tbody/tr[7]/td/table/tbody/tr/td[3]/a/img")).click();
		String ExpectedTitle = "Sign-on: Mercury Tours";
		String actualTitle = driver.getTitle();
		CaptureScrShot.takeSnapShot(driver, "LogoutSignOnPage.png");
		Assert.assertEquals(actualTitle, ExpectedTitle);
	}

	@AfterTest
	public void closeBrowser() {
		driver.close();
	}


}
