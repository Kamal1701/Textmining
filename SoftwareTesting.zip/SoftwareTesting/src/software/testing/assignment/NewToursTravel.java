package software.testing.assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewToursTravel {
	public String baseUrl = "http://newtours.demoaut.com";
	public String driverPath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
	public WebDriver driver;
	//loginPage ln;

	@BeforeClass
	public void invokeBrowser() {
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to(baseUrl);
		driver.manage().window().maximize();
	}

	@Test
	public void validate_homepage() throws Exception {
		String ExpectedTitle = "Welcome: Mercury Tours";
		String actualTitle = driver.getTitle();
		CaptureScrShot.takeSnapShot(driver, "C:\\Users\\Kamalakannan\\eclipse-workspace\\SoftwareTesting\\ScrSht\\Homepage.png");
		Assert.assertEquals(actualTitle, ExpectedTitle);
	}
	
	@AfterTest
	public void closeBrowser() {
		driver.close();
	}
}
