package software.testing.assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginPageTest {
	public String baseUrl = "http://newtours.demoaut.com";
	public String driverPath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
	public WebDriver driver;
	//loginPage ln;

	@BeforeTest
	public void invokeBrowser() {
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.navigate().to(baseUrl);
		driver.manage().window().maximize();
	}

//	@Test
//	public void verifyPageTitle() {
//		String ExpectedTitle = "OrangeHRM";
//		String actualTitle = driver.getTitle();
//		Assert.assertEquals(actualTitle, ExpectedTitle);
//	}
	
	@Test
	public void click_submit() throws Exception {
		Thread.sleep(2000);
		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userName")).sendKeys("admin");
		driver.findElement(By.name("password")).clear();
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		String ExpectedTitle = "Find a Flight: Mercury Tours: ";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, ExpectedTitle);
		CaptureScrShot.takeSnapShot(driver, "C:\\Users\\Kamalakannan\\eclipse-workspace\\SoftwareTesting\\ScrSht\\LoginPage.png");
	}
	
	@AfterTest
	public void closeBrowser() {
		driver.close();
	}

}
